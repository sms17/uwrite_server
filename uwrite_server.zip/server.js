var express = require('express');
var app = express();
var sql = require("mssql");

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.get('/person', function (req, res) {
    var personList = [];
    // config for your database
    var config = {
        user: 'sa',
        password: 'sqlserver12',
        server: 'LAPTOP-FSK8502H', 
        database: 'employee' 
    };
    var personList = [];
    // connect to your database
    sql.connect(config, function (err) {

        // create Request object
        var request = new sql.Request();

        // query to the database and get the records
        request.query("SELECT  * FROM users"
        , function (err, result) {

            if (err) 
            return next(err);

        var data = {};
        data = result.recordset;
        //res.send(data);    
        res.render('home', {"personList": data});
           sql.close();

        });
        
    });
});

var server = app.listen(5000, function () {
    console.log('Server is running..');
});